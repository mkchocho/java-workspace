package com.sy.run;

import com.sy.view.MainMenu;

public class Run {

	public static void main(String[] args) {

		
		new MainMenu().mainMenu();
		
		
	}

} 